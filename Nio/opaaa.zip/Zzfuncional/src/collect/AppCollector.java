package collect;

import java.util.List;
import java.util.Map;
import static java.util.stream.Collectors.groupingBy;

public class AppCollector {

	public static void main(String[] args) {
		List<Empleado> empleados = List.of(
				new Empleado("AFRI:3", 12000),
				new Empleado("Alexis", 5000),
				new Empleado("Kevs", 10000),
				new Empleado("Juan4", 0),
				new Empleado("Nico", 0),
				new Empleado("Canelita", 20000)
				);
		
		Map<String, List<Empleado>> porDept = empleados  
				.stream()   
				.collect(groupingBy(Empleado::getNombre));
		
		System.out.println(porDept);
	}

}
