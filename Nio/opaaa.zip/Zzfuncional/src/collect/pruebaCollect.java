package collect;

public class pruebaCollect {
	
}
