package collect;

public class Empleado {
	private static int idStatic = 1;
	private int id;
	private String nombre;
	private double salario;
	//private String departamento;
	//private String ciudad;

	public Empleado(String nombre, double salario) {
		super();
		this.id = idStatic++;
		this.nombre = nombre;
		this.salario = salario;
		//this.departamento = departamento;
		//this.ciudad = ciudad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/*public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}*/

	public double getSalario() {
		return salario;
	}
	
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public int getId() {
		return id;
	}
	/*
	@Override
	public String toString() {
		return "Empleado [nombre=" + nombre + ", departamento=" + departamento + ", ciudad=" + ciudad + "]";
	}*/


}
