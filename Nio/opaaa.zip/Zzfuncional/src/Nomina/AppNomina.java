package Nomina;

import java.util.List;

public class AppNomina {

	public static void main(String[] args) {
		List<Nomina> nominas = List.of(
				new Nomina("Juan", List.of("Sueldo Base","Transporte")),
				new Nomina("Juan", List.of("Sueldo Base","Bonos navidad")),
				new Nomina("Juan", List.of("Sueldo Base","Horas extra"))							
				);
		//Que hace -> 
		int totalConceptos1 = nominas.stream()
				.map(n -> n.conceptos().size())
				.reduce(0, Integer::sum);
		
		
		
		// Que hace -> llevar las nominas a un solo stream y contarlos
		// OJO: Mirar que distinc... observara el stream ??? lo mismo que veerlo en un array o parecido?? 
		long totalConceptos = nominas.stream()
				.flatMap(n -> n.conceptos().stream())
				.distinct()
				.count();
		
	}

}
