package lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateExamples {

	public static void main(String[] args) {
		// Ejercicio 16
		Predicate<Integer> positivo = num -> num > 0;
		// Ejercicio 17
		Predicate<String> vacio = str -> str.length() == 0;
		// Ejercicio 18
		Predicate<Integer> esPar = num -> num % 2 == 0;
		// Ejercicio 19
		Predicate<String> longitudMayor = str -> str.length() > 5;
		// Ejercicio 20
		Predicate<List<Integer>> listaVacia = lista -> lista.size() == 0;
		
		System.out.println(positivo.test(54)); // true
		System.out.println(vacio.test("Canelita")); // false
		System.out.println(esPar.test(6)); //true
		System.out.println(longitudMayor.test("Afriquita :3")); // true
		List<Integer> lisanueva = new ArrayList<>(Arrays.asList(1,2,3,4));
		System.out.println(listaVacia.test(lisanueva)); //false

	}

}
