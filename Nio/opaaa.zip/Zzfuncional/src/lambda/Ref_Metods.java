package lambda;

public class Ref_Metods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
