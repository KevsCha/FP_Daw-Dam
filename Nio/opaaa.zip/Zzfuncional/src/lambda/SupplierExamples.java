package lambda;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

public class SupplierExamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Ejercicio 1
		Supplier<Double> num = () -> Math.random(); 
		// Ejercicio 2
		Supplier<LocalDate> fecha = () -> LocalDate.now();
		// Ejercicio 3
		Supplier<String> saludo = () -> {
			List<String> lista = List.of("Afriquita <3 \\(*~*)/", "Canelitaaaaaaa!!!!");
			return lista.get((int) (Math.random() * 2) + 0);
		};
		// Ejercicio 4
		Supplier<String> nom = () -> "KAFS";
		// Ejercicio 5
		Supplier<UUID> id = () -> UUID.randomUUID();
		
		
		
		
		
		
		
		
		
		// Por pantalla
		System.out.println(num.get());
		System.out.println(fecha.get());
		System.out.println(saludo.get());
		System.out.println(nom.get());
		System.out.println(id.get());
		System.out.println(id.get());
		System.out.println(id.get());
		System.out.println(id.get());
		System.out.println(id.get());
	}
	
	

}
