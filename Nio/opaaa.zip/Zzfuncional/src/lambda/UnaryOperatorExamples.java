package lambda;

import java.util.function.UnaryOperator;

public class UnaryOperatorExamples {

	public static void main(String[] args) {
		// Ejercicio 6
		UnaryOperator<Integer> mult_siete = x -> x * 7;
		// Ejercicio 7
		UnaryOperator<String> duplicarStr = x -> {
			String y;
			y = x;
			return y;
			};
		// Ejercicio 8
		UnaryOperator<Integer> sumCinco = x -> x + 5;
		// Ejercicio 9
		UnaryOperator<String> replace = x -> x.replace(',', '"');
		// Ejercicio 10
		UnaryOperator<Double> invertirSigno = x -> x * (-1);
		
		
		
		System.out.println(mult_siete.apply(-10));
		System.out.println(duplicarStr.apply("Q onda, mijo"));
		System.out.println(sumCinco.apply(-4));
		System.out.println(replace.apply("Que, genial, todo,,,"));
		System.out.println(invertirSigno.apply(-13.0));
		
	}

}
