package lambda;

import java.util.function.Function;

public class FunctionExamples {

	public static void main(String[] args) {
		// Ejercicio 11
		Function<Integer, String> conveertLiteral = num -> String.valueOf(num);
		// Ejercicio 12
		Function<String, Integer> longitud = str -> str.length();
		// Ejercicio 13
		Function<Integer, Double> raiz = num -> Math.sqrt(num);		
		// Ejercicio 14
		Function<String, String> replace = str -> str.replace(' ', '-');		
		// Ejercicio 15
		Function<Integer, String> mult = num -> String.valueOf(num * 2);		
		
		System.out.println(conveertLiteral.apply(543));
		System.out.println(longitud.apply("hola"));
		System.out.println(raiz.apply(10));
		System.out.println(replace.apply("quiero jugar voley porfa :c :c"));
		System.out.println(mult.apply(5));

	}

}
