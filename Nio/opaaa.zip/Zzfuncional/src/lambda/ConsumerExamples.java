package lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ConsumerExamples {
	public static void main(String[] args) {
		// Ejercicio 21
		Consumer<String> consola = mensaje -> System.out.println("Mensaje: " + mensaje);
		// Ejercicio 22 
		Consumer<Integer> multiplicar = num -> System.out.println("Multiplicacion: " + num * 2);		
		// Ejercicio 23 
		Consumer<String> length = str -> System.out.println("Longitud: " + str.length());
		// Ejercicio 24
		Consumer<String> upperCase = str -> System.out.println("Mensaje: " + str.toUpperCase());
		// Ejercicio 25
		Consumer<List<Integer>> recorrerLista= lista -> {
			for (Integer num : lista) {
				System.out.print(num + " ");
			}
		}; 
		
		
		consola.accept("Este muas muas para mi afri <3");
		multiplicar.accept(5);
		length.accept("Mi Afri Hermosa");
		upperCase.accept("hoy es el dia del platano, chicheñol");
		recorrerLista.accept(new ArrayList<>(Arrays.asList(01,222,07,26,10,25)));
	}
}
