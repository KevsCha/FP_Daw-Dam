package lambda;

import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class Varios {

	public static void main(String[] args) {
		// Ejercicio 1
		BinaryOperator<Integer> suma = (x,y) -> x + y;
		// Ejercicio 2
		BinaryOperator<Integer> m = (x,y) -> x * y; 
		// Ejercicio 3
		UnaryOperator<Integer> cuadro = x -> x * x;
		// Ejercicio 4
		Predicate<Integer> esImpar = x -> x % 2 == 1;
		// Ejercicio 5
		UnaryOperator<String> mayusculas = x -> x.toUpperCase();
		// Ejercicio 6
		BinaryOperator<String> cadena = (x,y) -> x.concat(y);
		// Ejercicio 7
		Function<String, Character> caracter = x -> x.charAt(x.length() - 1); 
		// Ejercicio 8
		Predicate<String> letraPorA = x -> x.charAt(0) == 'A'; 
		// Ejercicio 9
		Consumer<Integer> numDet = x -> {
			if (x > 0)
				System.out.println("el numero es positivo");
			if (x < 0)
				System.out.println("el numero es negativo");
			if (x == 0)
				System.out.println("el numero es 0");
		};
		// Ejercicio 10
		BinaryOperator<Integer> mayor = (x,y) -> (x > y ? x : y);
		// Ejercicio 11
		UnaryOperator<String> invertir = x -> new StringBuilder(x).reverse().toString();
		// Ejercicio 12
		UnaryOperator<String> remplazo = str -> str.replace(' ', '-');
		// Ejercicio 13
		Predicate<String> verificar = str -> str.contains("Java");
		// Ejercicio 14
		BiPredicate<Integer, Integer> sumaBol = (x,y) -> x + y > 100; 
		// Ejercicio 15
		Predicate<Integer> multiplo = x -> x % 3 == 0;
		
		//----------------------------------
		System.out.println(suma.apply(15, 30)); // 45
		System.out.println(m.apply(5, 4)); // 20 
		System.out.println(cuadro.apply(5)); // 25 
		System.out.println(esImpar.test(1)); // true
		System.out.println(mayusculas.apply("canelita ya crecio!!! :o")); // mayusculas 
		System.out.println(cadena.apply("Afriii y...", "KEVS con canelita")); // afriii y... KEVS xon canelita 
		System.out.println(caracter.apply("AFRIIII ME DEJoooOOoo :c")); // c
		System.out.println(letraPorA.test("aaahhh Primera letra A???")); // true 
		numDet.accept(-1); // 0
		System.out.println(mayor.apply(345, 55)); // 55
		System.out.println(invertir.apply("AFRIII TE AMOOO")); // invertir
		System.out.println(remplazo.apply("remplazame los espacio por fis ehheh ehehe hehe")); //cambio de ' ' a -
		System.out.println(verificar.test("No tengo Java la palabra, AFRIIIIIIIIIIIIIII on TASSSSS")); // false
		System.out.println(sumaBol.test(103, 10)); // false
		System.out.println(multiplo.test(20)); // true
	}

}
