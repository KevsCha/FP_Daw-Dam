package streamApi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import collect.Empleado;

public class StreamApi {

	public static void main(String[] args) {
		// 1. Imprimir cada elemento de una lista de enteros
		List<Integer> num = List.of(1,2,3,4,5,6,7);
		num.forEach(System.out::println);
	    // 2. Imprimir cada nombre en mayúsculas en una lista de nombres
		List<String> nombs = List.of("Afri<3","Kevs","Canelita","Alexis","JP");
		List<String> yy = nombs.stream().map(String::toUpperCase).toList();
		System.out.println(yy);
	    // 3. Sumar todos los elementos de una lista dentro del forEach
		// Con el uso de forEach significa que no utilizaremos la INMUTABILIDAD, nos esta forzando a romper la filosofia de los streams
		List<Integer> sum = List.of(1,2,3,4,5,6,7);
		int[] aux = {0};
		sum.forEach(n -> aux[0] += n);
		System.out.println("Acumulador: " + aux[0]);
	    // 4. Multiplicar cada número de una lista por 2 y mostrarlo
		List<Integer> multx2 = List.of(1,2,3,4,5,6,7);
		multx2.stream().map(n -> n * 2).forEach(System.out::println);
	    // 5. Agregar un sufijo a cada nombre en una lista
		List<String> sufijo = List.of("Afri<3","Kevs","Canelita","Alexis","Loca");
		sufijo = sufijo.stream().map(n -> n.concat("-chan")).toList();
		System.out.println(sufijo);
	    // 6. Sumar todos los números de una lista
		List<Integer> forma2 = List.of(1,2,3,4,5,6,7);
		int okkkPutuchufa = forma2.stream().mapToInt(Integer::intValue).sum();
		System.out.println(okkkPutuchufa);
		System.out.println("_______________OtraForma______________");
		int suma2 = forma2.stream().reduce((x, y) -> x + y).orElse(0);
		System.out.println(suma2);
	    // 7. Multiplicar todos los números de una lista y guardar el resultado en una variable
		List<Integer> multRed = List.of(1,2,3,4,5);
		int mult2forma = multRed.stream().reduce((x,y) -> x*y).orElse(0);
		System.out.println(mult2forma);
	    // 8. Encontrar el número mayor en una lista
		List<Integer> encontrarMayor = List.of(0,-2,3,64,45);
		int mayor = encontrarMayor.stream()
						.reduce(Integer.MIN_VALUE, (x,y) -> x > y ? x :y);
		System.out.println(mayor);
	    // 9. Concatenar una lista de palabras en una sola cadena
		List<String> listaPalabras = List.of("Kevin ","y ","Afri ","Por ","El ","Mundo.");
		String l = listaPalabras.stream().reduce("",(x,y) -> x.concat(y));
		System.out.println(l);
	    // 10. Contar el número de caracteres en una lista de palabras
		List<String> listaPalabras2 = List.of("Kevin ","y ","Afri ","Por ","El ", "Mundo.");
		
		
		int len = listaPalabras2.stream().map( x -> x.length()).reduce(0 , (acum, numm) -> acum + numm);
		System.out.println(len);
		int len2 = listaPalabras2.stream().mapToInt(x -> x.length()).sum();
		System.out.println(len2);		
	    // 11. Contar cuántos elementos hay en una lista de números
		List<Integer> contarlista = List.of(0,-2,3,64,45);
		System.out.println(contarlista.stream().count());
		
	    // 12. Contar cuántos nombres tienen más de 4 letras
		List<String> listaPalabras3 = List.of("Kevin ","y ","Afri ","Por ","El ", "Mun", "canelita");
		System.out.println("contar nombre: " + listaPalabras3.stream().filter(x -> x.length() > 4).count());
		
	    // 13. Contar cuántos números son mayores que 10 
		List<Integer> contarlista2 = List.of(0,-2,3,64,45);
		System.out.println(contarlista2.stream().filter(x -> x > 10).count());
	    // 14. Contar cuántas palabras comienzan con una vocal
		System.out.println("____________Ejercico 14_____________");
		List<String> listaPalabras4 = List.of("Kevin ","y ","Afri ","Por ","El ", "Mun", "canelita");
		listaPalabras4.stream().map(x -> x.trim().toLowerCase().charAt(0))
			.filter(c -> "aeiou".indexOf(c) != -1)
			.forEach(System.out::println);
			
	    // 15. Contar cuántos números son pares en una lista
		List<Integer> contarlista3 = List.of(0,-2,3,64,45);
		System.out.println(contarlista3.stream().filter(x -> x % 2 == 0).count());
	    // 16. Modificar los valores de una lista de enteros (multiplicar por 3 cada valor)
		System.out.println("---------------Ejercicio 16-----------------");
		List<Integer> contarlista4 = List.of(0,-2,3,64,45);
		contarlista4.stream().map(x -> x *3).forEach(x -> System.out.println(x));		
	    // 17. Convertir una lista de nombres en sus iniciales y almacenarlas en otra lista
		System.out.println("---------------Ejercicio 17-----------------");
		List<String> listaNombre= List.of("Kevin David Quispe","Africa Narganes Ferrer","Erick Alexis Venegas","Juan Pvtero", "Canelita Ferrer Quispe");
		List<String> nuevaLista =  listaNombre.stream() // La cinta transporta el primer elemento
				.map(x -> Arrays.asList((x.split(" "))) // convierte los elementos en un Array de string con sus nombres
						.stream()//A ese array los convierte en otro stream para utilizar las interfaces funcionales
						.map(palabra -> String.valueOf(palabra.charAt(0)))//cada elemento del segundo stream 
						.collect(Collectors.joining()))// 
				.toList();
		System.out.println(nuevaLista);
	    // 18. Sumar los valores de un Map y almacenarlos en una variable externa
		System.out.println("---------------Ejercicio 18-----------------");
		Map<String, Integer> mapList = new HashMap<>(Map.of("id_Kevs",  8,"id_Afri", 2, "id_Canelita", 26));
		System.out.println(mapList.values().stream().reduce((x,y) -> x + y));
		
	    // 19. Reemplazar cada valor de una lista de enteros según una condición
		System.out.println("---------------Ejercicio 19-----------------");
		Map<String, Integer> mapList2 = new HashMap<>(Map.of("id_Kevs",  8,"id_Afri", 2, "id_Canelita", 26, "id_Alexis", -10, "id_jp", 0, "id_alex", -20));
		
		System.out.println(mapList2.values().stream().mapToInt(x -> x >= 0 ? x : 0).sum()); 
		
	    // 20. Agregar los valores de un array a un conjunto utilizando forEach
		System.out.println("---------------Ejercicio 20-----------------");
		int [] arrayNum = {1,2,2,4,5,6,6,8,9,9};
		Set<Integer> conjunto = new HashSet<>();
		Arrays.stream(arrayNum).forEach(conjunto::add);
		System.out.println(conjunto);
		//21. Calcular el máximo número par de una lista
		System.out.println("---------------Ejercicio 21-----------------");
		List<Integer> maximoList = List.of(22,2,2007,3,7,2001,26,10,2025);
		int ejercicio21 = maximoList.stream()
			.filter(Objects::nonNull)
			.reduce(0, (x, y) -> x > y ? x : y);
		System.out.println(ejercicio21);
		
		 //22. Determinar si todos los elementos de una lista son positivos
		System.out.println("---------------Ejercicio 22-----------------");
		List<Integer> verificarlista = List.of(22,2,2007,3,7,2001,26,10,2025);
		System.out.println(verificarlista.stream().allMatch(x -> x > 0));
		verificarlista.stream().distinct();
		
		//23. Encontrar la palabra más larga en una lista de strings
		System.out.println("---------------Ejercicio 23-----------------");
		List<String> palatraLarga = List.of("Querida Afriii ","quiero que sepas ","que te quiermo ","Mucho mucho mucho","Lucharemos junto a ", "canelita.");
		System.out.println(palatraLarga.stream()
										.filter(Objects::nonNull)
										.reduce("", (x, y) -> x.length() > y.length() ? x : y)); 
		System.out.println(palatraLarga.stream()
							.filter(Objects::nonNull)
							.max(Comparator.comparingInt(String::length)) //Max es mucho mas efectivo y utiliza un comparator y devuelve un optional 
							.orElse("No hay palabras")); //Para Optional hay que utilizar un metodo de seguridad en caso de que este vacio... orElse
		
		//24. Concatenar solo las palabras que tengan más de 4 letras
		System.out.println("---------------Ejercicio 24-----------------");
		List<String> listaPalabras5 = List.of("Kevin ","y ","Afri ","Por ","El ", "Mun", "canelita");
		String concatList = listaPalabras5.stream()
								.filter(Objects::nonNull)
								.filter(x -> x.length() > 4)
								.reduce("", (x,y) -> x.concat(y));
		System.out.println(concatList);
		System.out.println(listaPalabras5.stream()
							.filter(Objects::nonNull)
							.filter(x -> x.length() > 4) //hasta aqui pasan los que cumplen la condicion del filter
							.collect(Collectors.joining(", ")));
		//25. Calcular el factorial de un número usando reduce
		System.out.println("---------------Ejercicio 25-----------------");
		int nume = 5;
		System.out.println(IntStream.rangeClosed(1, nume).reduce(1, (x,y) -> x * y));
		System.out.println(Stream.iterate(nume, x -> x -1).limit(5).reduce(1, (x,y) -> x * y));
		//26. Contar cuántas cadenas contienen al menos un dígito
		System.out.println("---------------Ejercicio 26-----------------");
		List<String> listaPalabras6 = List.of("Ke2vin ","y ","A2fri ","Por ","2El ", "M1un", "canelita");
		System.out.println(listaPalabras6.stream().filter(Objects::nonNull).filter(x -> x.chars().anyMatch(c -> Character.isDigit(c))).count());
	
		//27. Contar cuántos empleados ganan más de 3000 y almacenarlos en un Map
		System.out.println("---------------Ejercicio 27-----------------");
		int idEmpleado = 0;
		List<Empleado> empleados = List.of(
									new Empleado("Kevin", 10000),
									new Empleado("Africa", 10000),
									new Empleado("Canelita", 2000),
									new Empleado("Gala", 1500),
									new Empleado("Noha", 3000));
		
		Map<Integer, Empleado> empSalary = empleados.stream()
				.filter(x -> x.getSalario() > 3000)
				.collect(Collectors.toMap(
						e -> e.getId(), 
						e -> e
						));
		System.out.println(empSalary.size());
		
		//28. Contar cuántos números en una lista son primos (usar rangeClosed)
		System.out.println("---------------Ejercicio 28-----------------");
		List<Integer> primos = List.of(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15);		
		primos.stream()
			.filter(x -> x > 1)
			.filter(x -> IntStream
					.rangeClosed(2, (int)Math.sqrt(x))
					.noneMatch(d -> x % d == 0)
					).forEach(System.out::println);// Se hace con count
		
		//29. Contar cuántos strings en una lista son palíndromos
		System.out.println("---------------Ejercicio 29-----------------");
		List<String> listaPalindromos = List.of("Ana ",
												" yd d",
												"papap ",
												"Oso",
												"hannaH", 
												"", 
												"canelita");
		
		listaPalindromos.stream()
						.filter(Objects::nonNull)
						.map(x -> x.toLowerCase().trim())
						.filter(x -> {
							String y = new StringBuilder(x).reverse().toString();
							return x.equals(y);
						}).forEach(System.out::println);
		//30. Contar cuántos números en un array cumplen una condición específica (múltiplos de 5 y mayores que 10)
		System.out.println("---------------Ejercicio 30-----------------");
		List<Integer> especifico = List.of(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,20);
		System.out.println(especifico.stream()
					.filter(x -> x % 5 == 0 && x > 10)
					.count());
		//31. Encontrar el primer número par en una lista de enteros
		System.out.println("---------------Ejercicio 31-----------------");
		List<Integer> parList = List.of(-1,1,3,5,7,121,9,1,11,1,1,1,15,1);
		System.out.println( parList.stream().filter(x -> x % 2 == 0).findFirst().orElse(-1));
		//32. Encontrar cualquier número mayor que 50 en una lista
		System.out.println("---------------Ejercicio 32-----------------");
		List<Integer> mayorFifty = List.of(-1,1,3,35,78,121,91,1,11,1200,1,1,105,100);
		System.out.println(mayorFifty.parallelStream().filter(x -> x > 50).findAny().orElse(-1)); 
		
		//33. Obtener el primer nombre que empiece con "M" en una lista
		System.out.println("---------------Ejercicio 33-----------------");
		List<String> primerNomb = List.of("Kevin ","Galita","Afri","Muejjeje", "M1un", "canelita");
		//hy6nn7mujejejejje
		System.out.println(primerNomb.stream()
					.filter(x -> x.toLowerCase().charAt(0) == 'm')
					.findAny().orElse("No encontre nada.")); 
		
		//34. Buscar cualquier número negativo en una lista
		System.out.println("---------------Ejercicio 34-----------------");
		List<Integer> menorList = List.of(1,1,-3,35,78,-121,-91,1,11,-1200,1,1,105,100);
		System.out.println(menorList.stream().filter(x -> x < 0).findAny().orElse(0)); 
		
		//35. Encontrar el primer string con más de 5 caracteres
		System.out.println("---------------Ejercicio 35-----------------");
		List<String> cuaList = List.of("Kevin ","Galita","Afri","Muejjeje", "M1un", "canelita");
		System.out.println(cuaList.stream().filter(x -> x.length() > 5).findFirst().orElse("Ninguna encontrada!!")); 
		//36. Verificar si hay algún número mayor que 100 en una lista
		System.out.println("---------------Ejercicio 36-----------------");
		System.out.println(menorList.stream().anyMatch(x -> x > 100));
		
		//37. Comprobar si todos los elementos de una lista son pares
		System.out.println("---------------Ejercicio 37-----------------");
		menorList = List.of(2,4,6,100);
		System.out.println(menorList.stream().allMatch(x -> x % 2 == 0));
		
		//38. Determinar si ninguna palabra en una lista empieza con "Z"
		System.out.println("---------------Ejercicio 38-----------------");
		cuaList = List.of("Kevs","Afri","zeus","Canelita","Noha");
		System.out.println(cuaList.stream().allMatch(x -> x.toLowerCase().charAt(0) != 'Z'));
		//39. Verificar si alguna persona en una lista tiene más de 30 años
		System.out.println("---------------Ejercicio 39-----------------");
		List<Persona> listPersonas = List.of(
										new Persona("Afri", 19),
										new Persona("Kevs", 24),
										new Persona("Canelita", 1));
		System.out.println(listPersonas.stream().anyMatch(x -> x.getEdad() > 30));
		//40. Comprobar si todas las cadenas de una lista tienen al menos 3 caracteres
		System.out.println("---------------Ejercicio 40-----------------");
		cuaList = List.of("Kevs","Afri","zeus","Canelita","Noha");
		System.out.println(cuaList.stream().allMatch(x -> x.length() > 3));
		//41. Convertir una lista de strings en una sola cadena separada por comas (usar Collectors)
		System.out.println("---------------Ejercicio 41-----------------");
		List<String> join = List.of("Kevin ","Galita","Afri","Muejjeje", "M1un", "canelita");
		System.out.println(join.stream().filter(Objects::nonNull).collect(Collectors.joining(", "))); 
		//42. Filtrar los números mayores de 10 y almacenarlos en una nueva lista 
		System.out.println("---------------Ejercicio 42-----------------");
		menorList = List.of(1,1,-3,35,78,-121,-91,1,11,-1200,1,1,105,100);
		System.out.println(menorList.stream()
							.filter(Objects::nonNull)
							.filter(x -> x > 10)
							.collect(Collectors.toList())
										.toString()
							); 
		
		//43. Convertir una lista de palabras a un conjunto eliminando duplicados 
		join = List.of("Kevin ","Galita","Afri","Afri", "M1un", "canelita", "kevin");
		System.out.println("---------------Ejercicio 43-----------------");
		Set<String> noDu = join.stream().filter(Objects::nonNull)
							.filter(x -> !x.isEmpty())
							.map(x -> x.trim().toString())
							.map(x -> x.substring(0,1).toUpperCase() + x.substring(1))
							.collect(Collectors.toSet());
		System.out.println(noDu);
		//44. Agrupar una lista de personas por edad (usar groupingBy) 
		System.out.println("---------------Ejercicio 44-----------------");
		listPersonas = List.of(
				new Persona("Afri", 19),
				new Persona("Kevs", 24),
				new Persona("Canelita", 1),
				new Persona("Alexis", 24),
				new Persona("Isa", 50),
				new Persona("Santi", 50));
		
		Map<Integer, List<Persona>> xxx =  listPersonas.stream().collect(Collectors.groupingBy(Persona::getEdad)); 
		
		System.out.println(xxx);
		//45. Sumar todos los elementos de una lista con collect 
		System.out.println("---------------Ejercicio 45-----------------");
		List<Integer> sumCol = List.of(1,1,-3,35,78,-121,-91,1,11,-1200,1,1,105,100);
		System.out.println(sumCol.stream().collect(Collectors.summingInt(x -> x)));
		//46. Encontrar el primer número primo en una lista de enteros 
		System.out.println("---------------Ejercicio 46-----------------");
		//47. Encontrar cualquier cadena en una lista que contenga al menos dos dígitos 
		System.out.println("---------------Ejercicio 47-----------------");
		//48. Buscar el primer empleado con salario mayor a 50,000 
		System.out.println("---------------Ejercicio 48-----------------");
		//49. Obtener cualquier ciudad de una lista que empiece con "B" y tenga más de 5 letras 
		System.out.println("---------------Ejercicio 49-----------------");
		//50. Encontrar el primer producto en una lista con stock mayor a 10 y precio menor de 20 
		System.out.println("---------------Ejercicio 50-----------------");
		//51. Verificar si hay algún estudiante con calificación superior a 90 
		System.out.println("---------------Ejercicio 51-----------------");
		//52. Comprobar si todos los productos en una lista tienen un precio mayor a 5 
		System.out.println("---------------Ejercicio 52-----------------");
		//53. Determinar si ninguna persona en una lista tiene menos de 18 años 
		System.out.println("---------------Ejercicio 53-----------------");
		//54. Verificar si hay algún número que sea potencia de 2 en una lista 
		System.out.println("---------------Ejercicio 54-----------------");
		//55. Comprobar si todos los correos en una lista tienen el dominio "gmail.com" 
		System.out.println("---------------Ejercicio 55-----------------");
		//56. Agrupar empleados por departamento (Empleado tiene nombre, salario y departamento de atributos) 
		System.out.println("---------------Ejercicio 56-----------------");
		//57. Contar cuántos empleados hay por departamento 
		System.out.println("---------------Ejercicio 57-----------------");
		//58. Obtener el salario promedio de una lista de empleados (usar Collectors) 
		System.out.println("---------------Ejercicio 58-----------------");
		//59. Concatenar todas las palabras de una lista separadas por espacio 
		System.out.println("---------------Ejercicio 59-----------------");
		//60. Crear un conjunto con los nombres de empleados sin duplicados (usar Collectors) 
		System.out.println("---------------Ejercicio 60-----------------");
		//61. Filtrar números pares de una lista 
		System.out.println("---------------Ejercicio 61-----------------");
		//62. Filtrar nombres que empiecen con "A" 
		System.out.println("---------------Ejercicio 62-----------------");
		//63. Obtener productos con precio mayor a 50 
		System.out.println("---------------Ejercicio 63-----------------");
		//64. Obtener la longitud de cada palabra en una lista 
		System.out.println("---------------Ejercicio 64-----------------");
		//65. Obtener los cuadrados de una lista de números 
		System.out.println("---------------Ejercicio 65-----------------");
		//66. Transformar una lista de empleados en una lista con sus nombres 
		System.out.println("---------------Ejercicio 66-----------------");
		//67. Obtener todas las palabras de una lista de frases (en una frase las palabras están separadas por espacio, coma o guion) 
		System.out.println("---------------Ejercicio 67-----------------");
		//68. Aplanar una lista de listas de números en una sola lista 
		System.out.println("---------------Ejercicio 68-----------------");
		//69. Extraer y almacenar todas las letras individuales (lista de caracteres) de una lista de palabras 
		System.out.println("---------------Ejercicio 69-----------------");
		//70. Ordenar una lista de números de menor a mayor 
		System.out.println("---------------Ejercicio 70-----------------");
		
		
		
	}

}



































//Amor perdona pero quiero hablarlo mas ratito y un poco mas ... nosotros perdona x cortarte pero la bulla 
		//me esta estresando xq tanto para ti como para mi es importante y si me importa enterarme 
		//al 100 y con la bulla no puedo