package stream_api2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import collect.Empleado;
import streamApi.Persona;

public class StreamApi {
	public static void main(String[] args) {
		
		List<Integer> num = List.of(1,2,3,4,5,6,7,8,9);
		List<Integer> numSup = List.of(121, -12, 0, 4, 543,-126,7,-8,19);
		List<String> listaNombre = List.of("Canelita", "Afriquita", "Kevs", "Familia" );
		List<String> listPalabra = List.of("Puchufita", "y", "Puchufito", "se", "quieren", "mucho");
		List<Integer> auxInt = null;
		List<String> aux = null;
		String onlyStr = null;
		int onlyNum;
		// 1. Imprimir cada elemento de una lista de enteros
		System.out.println("_________________Ejercicio 1___________________");
		num.stream().forEach(System.out::println);
		System.out.println(num.stream().map(x -> String.valueOf(x)).collect(Collectors.joining(", ")));
		// 2. Imprimir cada nombre en mayúsculas en una lista de nombres
		System.out.println("_________________Ejercicio 2___________________");
		listaNombre.stream().map(x -> x.toUpperCase()).forEach(System.out::println);
		aux = listaNombre.stream().map(String::toUpperCase).collect(Collectors.toList());
		System.out.println(aux);
		// 3. Sumar todos los elementos de una lista dentro del forEach
		System.out.println("_________________Ejercicio 3___________________");
		int[] acumulador = {0};
		num.stream().forEach(n -> acumulador[0] += n);
		System.out.println("Acumulador con array manejando el valor interno: " + acumulador[0]);
		System.out.println("reduce: " + num.stream().reduce(0, (x, y) -> x + y));
		System.out.println("Colect: " + num.stream().collect(Collectors.summingInt(x -> x)));
		
		// Con el uso de forEach significa que no utilizaremos la INMUTABILIDAD, nos esta forzando a romper la filosofia de los streams
		// 4. Multiplicar cada número de una lista por 2 y mostrarlo
		System.out.println("_________________Ejercicio 4___________________");
		
		num.stream().map(x -> x * 2).forEach(System.out::println);;
		// 5. Agregar un sufijo a cada nombre en una lista
		System.out.println("_________________Ejercicio 5___________________");
		aux = listaNombre.stream().map(x -> x.concat("_" + x.charAt(0))).toList();
		System.out.println(aux);
		onlyStr = listaNombre.stream().map(x -> x.concat("_" + x.charAt(0))).collect(Collectors.joining(", "));
		System.out.println(onlyStr);
		// 6. Sumar todos los números de una lista
		System.out.println("_________________Ejercicio 6___________________");
		onlyNum = num.stream().reduce(0 ,(x,y) -> x + y);
		System.out.println(onlyNum);
		// 7. Multiplicar todos los números de una lista y guardar el resultado en una variable
		System.out.println("_________________Ejercicio 7___________________");
		onlyNum = num.stream().reduce(1, (x,y) -> x * y);
		System.out.println(onlyNum);
		// 8. Encontrar el número mayor en una lista
		System.out.println("_________________Ejercicio 8___________________");
		onlyNum = num.stream().reduce(Integer.MIN_VALUE,(x, y) -> x > y ? x : y);
		System.out.println(onlyNum);
		// 9. Concatenar una lista de palabras en una sola cadena
		System.out.println("_________________Ejercicio 9___________________");
		onlyStr = listPalabra.stream().reduce("", (x, y) -> x.concat(" " + y));
		System.out.println(onlyStr.trim());
		onlyStr = listPalabra.stream().filter(Objects::nonNull).collect(Collectors.joining(" "));
		System.out.println(onlyStr);
		// 10. Contar el número de caracteres en una lista de palabras
		System.out.println("_________________Ejercicio 10___________________");
		onlyNum = listaNombre.stream().map(x -> x.length()).reduce(0, (x, y) -> x+ y);
		System.out.println("Map + reduce: " + onlyNum);
		onlyNum = listaNombre.stream().collect(Collectors.summingInt(x -> x.length()));
		System.out.println("Collectors: " + onlyNum);
		auxInt = listaNombre.stream().map(x -> x.length()).collect(Collectors.toList());
		System.out.println(auxInt);
		// 11. Contar cuántos elementos hay en una lista de números
		System.out.println("_________________Ejercicio 11___________________");
		onlyNum =  (int)num.stream().count();
		System.out.println(onlyNum);
		// 12. Contar cuántos nombres tienen más de 4 letras
		System.out.println("_________________Ejercicio 12___________________");
		onlyNum = (int)listaNombre.stream().filter(x -> x.length() > 4).count();
		System.out.println(onlyNum);
		// 13. Contar cuántos números son mayores que 10
		System.out.println("_________________Ejercicio 13___________________");
		onlyNum = (int)numSup.stream().filter(x -> x > 10).count();
		System.out.println(onlyNum);
		// 14. Contar cuántas palabras comienzan con una vocal
		System.out.println("_________________Ejercicio 14___________________");
		onlyNum =  (int)listaNombre.stream()
						.map(x -> x.trim().toLowerCase().charAt(0))
						.filter(c -> "aeiou".indexOf(c) != -1)
						.count();
		System.out.println("Contar palabra: " + onlyNum);
		// 15. Contar cuántos números son pares en una lista
		System.out.println("_________________Ejercicio 15___________________");
		onlyNum = (int)num.stream().filter(x -> x % 2 == 0).count();
		System.out.println(onlyNum);
		
		
		// 16. Modificar los valores de una lista de enteros (multiplicar por 3 cada valor)
		System.out.println("_________________Ejercicio 16___________________");
		auxInt = num.stream().map(x -> x * 3).toList();
		System.out.println(auxInt);
		
		
		// 17. Convertir una lista de nombres en sus iniciales y almacenarlas en otra lista
		System.out.println("_________________Ejercicio 17___________________");
		aux = listaNombre.stream().map(x -> String.valueOf(x.trim().charAt(0))).toList();
		System.out.println(aux);
		List<String> aaa = List.of("Africa Narganes Ferrer", "Kevin David Quispe", "Alexis Venegas");
		aux = aaa.stream()
				.map(x -> Arrays.asList(x.split(" ")) // Del primer elemento(Africa Narganes Ferrer) lo convierte en lista
								.stream()
								.map(a -> String.valueOf(a.trim().charAt(0))) // esa lista le saca los primero caracteres
								.collect(Collectors.joining())//Agrupa esos 3 primeros caracteres y los devuelve juntos
				).toList();//convierte en una lista todo lo demas.
		System.out.println(aux);
		// La cinta transporta el primer elemento
		// convierte los elementos en un Array de string con sus nombres
		//A ese array los convierte en otro stream para utilizar las interfaces funcionales
		//cada elemento del segundo stream
		// 
		// 18. Sumar los valores de un Map y almacenarlos en una variable externa
		System.out.println("_________________Ejercicio 18___________________");
		Map<Integer, Integer> mapList = new HashMap<>(Map.of(1,2, 2,123, 3,-12, 4,90, 5,-30)); 
		int map = 0;
		
		map = mapList.values().stream()
					.mapToInt(x -> x)//Integer::intValue
					.sum();
		System.out.println(map);
		// 19. Reemplazar cada valor de una lista de enteros según una condición
		System.out.println("_________________Ejercicio 19___________________");
		auxInt = numSup.stream()
				.filter(Objects::nonNull)
				.map(x -> x < 0 ? 5 : x)
				.toList();
		System.out.println(auxInt);
		// 20. Agregar los valores de un array a un conjunto utilizando forEach
		System.out.println("_________________Ejercicio 20___________________");
		int []arrayNum = {10,11,12,13,14,1,2,3,4};
		Set<Integer> set = new HashSet<>(num);
		Arrays.stream(arrayNum).forEach(x -> set.add(x));
		System.out.println(set);
		
		//21. Calcular el máximo número par de una lista
		System.out.println("_________________Ejercicio 21___________________");
		onlyNum = numSup.stream()
				.filter(Objects::nonNull).filter(x -> x % 2 == 0)
				.reduce(Integer.MIN_VALUE, (x, y) -> x > y ? x : y);
		System.out.println(onlyNum);
		
		//22. Determinar si todos los elementos de una lista son positivos
		System.out.println("_________________Ejercicio 22___________________");
		System.out.println(numSup.stream().allMatch(x -> x > 0));
		
		//23. Encontrar la palabra más larga en una lista de strings
		System.out.println("_________________Ejercicio 23___________________");
		onlyStr = listaNombre.stream()
					.max(Comparator.comparingInt(x -> x.length()))
					.orElse("No hay palabras");
		System.out.println(onlyStr);
		onlyStr = listaNombre
					.stream()
					.collect(Collectors.maxBy(Comparator.comparing(String::length)))
					.orElse("No hay Palabras");
		System.out.println(onlyStr);
		
		//Max es mucho mas efectivo y utiliza un comparator y devuelve un optional
		//Para Optional hay que utilizar un metodo de seguridad en caso de que este vacio... orElse
		//24. Concatenar solo las palabras que tengan más de 4 letras
		System.out.println("_________________Ejercicio 24___________________");
		onlyStr = listPalabra.stream().filter(x -> x.length() > 4).collect(Collectors.joining(" "));
		System.out.println(onlyStr);
		//hasta aqui pasan los que cumplen la condicion del filter
		//25. Calcular el factorial de un número usando reduce
		System.out.println("_________________Ejercicio 25___________________");
		onlyNum = IntStream.rangeClosed(1, 5).reduce(1, (x,y) -> x * y);
		System.out.println(onlyNum);
		onlyNum = Stream.iterate(5, x -> x - 1).limit(5).reduce(1, (x, y) -> x * y);
		System.out.println(onlyNum);
		
		//26. Contar cuántas cadenas contienen al menos un dígito
		System.out.println("_________________Ejercicio 26___________________");
		List<String> variado = List.of("canela 26", "Kevs", "Afri_222", "CodigoMUEJEJEJJE");
		onlyNum = (int)variado.stream()
						.filter(x -> x.chars()
									.anyMatch(Character::isDigit))
						.count();
		System.out.println(onlyNum);
		//27. Contar cuántos empleados ganan más de 3000 y almacenarlos en un Map
		System.out.println("_________________Ejercicio 27___________________");
		List<Empleado> empleados = List.of(
				new Empleado("Kevin", 10000),
				new Empleado("Africa", 10000),
				new Empleado("Canelita", 2000),
				new Empleado("Gala", 1500),
				new Empleado("Noha", 3000));
		
		Map<Integer, String> empleadosMap = empleados.stream()
												.filter(x -> x.getSalario() > 3000)
												.collect(Collectors.toMap(
														e -> e.getId()
														, e -> e.getNombre()
														));
		System.out.println(empleadosMap);
		//28. Contar cuántos números en una lista son primos (usar rangeClosed) //numero primo mayor a 1 si o si
		System.out.println("_________________Ejercicio 28___________________");//Es primo si divisor entre si mismo y el 1, 
		onlyNum = (int)num.stream()
							.filter(x -> x > 1)
							.filter(x -> IntStream.rangeClosed(2, (int)Math.sqrt(x))//solo es necesario comprobar con la raiz cuadra del numero que ingresa
											.noneMatch(d -> x % d == 0))//nonematch(cortocircuito) cuando se cumple la condicion se pasa al siguiente de la lista
							.count();
		System.out.println(onlyNum);
		// Se hace con count
		//29. Contar cuántos strings en una lista son palíndromos
		System.out.println("_________________Ejercicio 29___________________");
		List<String> listaPalindromos = List.of("Ana ",
				" yd d",
				"papap ",
				"Oso",
				"hannaH",  
				"canelita");
		onlyNum = (int)listaPalindromos.stream()
					.map(x -> x.trim().toLowerCase())
					.filter(x -> {
						String ab = new StringBuilder(x).reverse().toString();
						return x.equals(ab);
					}).count();
		System.out.println(onlyNum);
		//30. Contar cuántos números en un array cumplen una condición específica (múltiplos de 5 y mayores que 10)
		System.out.println("_________________Ejercicio 30___________________");
		List<Integer> arrayList = new ArrayList<>(List.of(10,4,3,5,20,25,6,2));
		//auxInt = arrayList.stream().filter(x -> x > 10 && x % 5 == 0).count();
		System.out.println();
		//31. Encontrar el primer número par en una lista de enteros
		System.out.println("_________________Ejercicio___________________");
		//32. Encontrar cualquier número mayor que 50 en una lista
		System.out.println("_________________Ejercicio___________________");
		//33. Obtener el primer nombre que empiece con "M" en una lista
		System.out.println("_________________Ejercicio___________________");
		//hy6nn7mujejejejje
		//34. Buscar cualquier número negativo en una lista
		System.out.println("_________________Ejercicio___________________");
		//35. Encontrar el primer string con más de 5 caracteres
		System.out.println("_________________Ejercicio___________________");
		//36. Verificar si hay algún número mayor que 100 en una lista
		System.out.println("_________________Ejercicio___________________");
		//37. Comprobar si todos los elementos de una lista son pares
		System.out.println("_________________Ejercicio___________________");
		//38. Determinar si ninguna palabra en una lista empieza con "Z"
		System.out.println("_________________Ejercicio___________________");
		//39. Verificar si alguna persona en una lista tiene más de 30 años
		System.out.println("_________________Ejercicio___________________");
		//40. Comprobar si todas las cadenas de una lista tienen al menos 3 caracteres
		System.out.println("_________________Ejercicio___________________");
		//41. Convertir una lista de strings en una sola cadena separada por comas (usar Collectors)
		System.out.println("_________________Ejercicio___________________");
		//42. Filtrar los números mayores de 10 y almacenarlos en una nueva lista
		System.out.println("_________________Ejercicio___________________");
		//43. Convertir una lista de palabras a un conjunto eliminando duplicados
		System.out.println("_________________Ejercicio___________________");
		//44. Agrupar una lista de personas por edad (usar groupingBy)
		System.out.println("_________________Ejercicio___________________");
		//45. Sumar todos los elementos de una lista con collect
		System.out.println("_________________Ejercicio___________________");
		//46. Encontrar el primer número primo en una lista de enteros
		System.out.println("_________________Ejercicio___________________");
		//47. Encontrar cualquier cadena en una lista que contenga al menos dos dígitos
		System.out.println("_________________Ejercicio___________________");
		//48. Buscar el primer empleado con salario mayor a 50,000
		System.out.println("_________________Ejercicio___________________");
		//49. Obtener cualquier ciudad de una lista que empiece con "B" y tenga más de 5 letras
		System.out.println("_________________Ejercicio___________________");
		//50. Encontrar el primer producto en una lista con stock mayor a 10 y precio menor de 20
		System.out.println("_________________Ejercicio___________________");
		//51. Verificar si hay algún estudiante con calificación superior a 90
		System.out.println("_________________Ejercicio___________________");
		//52. Comprobar si todos los productos en una lista tienen un precio mayor a 5
		System.out.println("_________________Ejercicio___________________");
		//53. Determinar si ninguna persona en una lista tiene menos de 18 años
		System.out.println("_________________Ejercicio___________________");
		//54. Verificar si hay algún número que sea potencia de 2 en una lista
		System.out.println("_________________Ejercicio___________________");
		//55. Comprobar si todos los correos en una lista tienen el dominio "gmail.com"
		System.out.println("_________________Ejercicio___________________");
		//56. Agrupar empleados por departamento (Empleado tiene nombre, salario y departamento de atributos)
		System.out.println("_________________Ejercicio___________________");
		//57. Contar cuántos empleados hay por departamento
		System.out.println("_________________Ejercicio___________________");
		//58. Obtener el salario promedio de una lista de empleados (usar Collectors)
		System.out.println("_________________Ejercicio___________________");
		//59. Concatenar todas las palabras de una lista separadas por espacio
		System.out.println("_________________Ejercicio___________________");
		//60. Crear un conjunto con los nombres de empleados sin duplicados (usar Collectors)
		System.out.println("_________________Ejercicio___________________");
		//61. Filtrar números pares de una lista
		System.out.println("_________________Ejercicio___________________");
		//62. Filtrar nombres que empiecen con "A"
		System.out.println("_________________Ejercicio___________________");
		//63. Obtener productos con precio mayor a 50
		System.out.println("_________________Ejercicio___________________");
		//64. Obtener la longitud de cada palabra en una lista
		System.out.println("_________________Ejercicio___________________");
		//65. Obtener los cuadrados de una lista de números
		System.out.println("_________________Ejercicio___________________");
		//66. Transformar una lista de empleados en una lista con sus nombres
		System.out.println("_________________Ejercicio___________________");
		//67. Obtener todas las palabras de una lista de frases (en una frase las palabras están separadas por espacio, coma o guion)
		System.out.println("_________________Ejercicio___________________");
		//68. Aplanar una lista de listas de números en una sola lista
		System.out.println("_________________Ejercicio___________________");
		//69. Extraer y almacenar todas las letras individuales (lista de caracteres) de una lista de palabras
		System.out.println("_________________Ejercicio___________________");
		//70. Ordenar una lista de números de menor a mayor
		System.out.println("_________________Ejercicio___________________");
		//Amor perdona pero quiero hablarlo mas ratito y un poco mas ... nosotros perdona x cortarte pero la bulla
		//me esta estresando xq tanto para ti como para mi es importante y si me importa enterarme
		//al 100 y con la bulla no puedo
	}
}
