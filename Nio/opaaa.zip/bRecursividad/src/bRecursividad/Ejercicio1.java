package bRecursividad;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(factorial(5));
	}
	
	public static int factorial(int numero) {
		if (numero == 1)
			return numero;
		return numero * factorial(numero - 1);
	}

}
//Cola: solo se llama a si mismo y ya, no incluye otras cosas --> mejor rendimiento pero no todos los lenguajes lo soportan
//no es cola, xq tiene que esperar a otro resultado y es menos eficiente en rendimiento