package recursividad;

public class Ejercicio1 {

	public static void main(String[] args) {
		System.out.println(sumaNum(5));

	}
	//Ejercicio 1
	public static int sumaNum(int num) {
		if (num == 1)
			return num;
		return num + sumaNum(num - 1);
	}
	//Ejercicio 2
	public static int contDigit(int num, int acumulador){
		if (num < 10)
			return 1;
		else {
			
		}
		
		
		return num;
	}
	//Ejercicio 3
	public static String invertirString() {
		return "";
	} 

}
