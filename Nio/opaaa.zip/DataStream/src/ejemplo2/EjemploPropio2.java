package ejemplo2;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class EjemploPropio2 {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("numero.dat")))){
			for(int i = 0; i < 10; i++) {
				System.out.println("Valor: ");
				out.writeDouble(sc.nextDouble());
			}
		}catch(IOException e) {
			System.err.println("Error e/s");
		}

	}

}
