package interfaces;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class Pdf_pruebas {
	public static void main(String[] args) {
	
		
		//-------------------------Function---------------------------------
		Function<String, Integer> longitud = str -> str.length();
		System.out.println(longitud.apply("Java"));
		//-------------------------CONSUMER---------------------------------
		Consumer<String> imprimir = mensaje -> System.out.println("Mensaje: " + mensaje);
		imprimir.accept("Hola"); // Hola, mundo
		
		//-------------------------SUPLIER---------------------------------
		// Supplier que devuelve un mensaje
		Supplier<String> mensajeSupplier = () -> "Hola, bienvenido";
		// Llamamos a get() para obtener el valor
		System.out.println(mensajeSupplier.get());
		
		//-------------------------UnaryOperator---------------------------------
		UnaryOperator<Integer> cuadrado = x -> x * x;
		UnaryOperator<Integer> valorAbs = x -> Math.abs(x);
		System.out.println(cuadrado.apply(5)); // 2
		System.out.println(valorAbs.apply(5)); // 2
		
		
		Pdf_pruebas.operar(cuadrado, 5);
		Pdf_pruebas.operar(valorAbs, 10);
	}
	
	public static int operar(UnaryOperator<Integer> operacion, int x) {
		return operacion.apply(x);
	}
	
}
