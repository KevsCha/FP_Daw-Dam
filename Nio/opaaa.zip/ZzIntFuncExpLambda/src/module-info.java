/**
 * 
 */
/**
 * 
 */
module ZzIntFuncExpLambda {
}