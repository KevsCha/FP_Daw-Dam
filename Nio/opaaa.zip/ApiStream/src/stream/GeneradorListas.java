package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;
import java.util.stream.Stream;


public class GeneradorListas {

	public static void main(String[] args) {
		
		
		List<Transaccion> transacciones=Arrays.asList(
				new Transaccion(new Proveedor("Sydney"),34,1200),
				new Transaccion(new Proveedor("Nairobi"),33,1200),
				new Transaccion(new Proveedor("Ushuaia"),45,4200),
				new Transaccion(new Proveedor("Katmandu"),35,1200),
				new Transaccion(new Proveedor("Osaka"),31,2500),
				new Transaccion(new Proveedor("Cali"),34,2300),
				new Transaccion(new Proveedor("Paris"),120,120000)				
				);
		
		List<Empleado> empleados=Arrays.asList(
				new Empleado("SpongeBob","Krusty Krab","Bikini Bottom"),
				new Empleado("Michael Knight","Knight Industries","Stanford"),
				new Empleado("Clark Kent","Daily Planet","Metropolis"),
				new Empleado("Neil Peart","Music","Hamilton")
				);
		
		
		
		List<String> ciudades = Arrays.asList("Cali", "Bogota", "Medellin", "Cali", "Peru");
		List<String> distintas = ciudades.stream().distinct().toList();
		
		System.out.println(ciudades.stream().distinct().toList());
		System.out.println("********************************");
		ciudades.stream().forEach(System.out::println);
		
		//----------------------maptoDouble---------------------------
		List<Transaccion> trxs = new ArrayList<Transaccion>(transacciones);
				//Stream de decimales cuyos elementos son el valor de  las transacciones 
		DoubleStream  stream = trxs.stream().mapToDouble(Transaccion::getValor);
		System.out.println("********************************");
		
		//----------------------maptoInt---------------------------
		List<String> paises =  Arrays.asList("Colombia", "México", "Guatemala"); 
		//Stream de enteros cuyos elementos son el num de  caracteres de los países   
		IntStream  str = paises.stream().mapToInt(String::length);
		System.out.println("********************************");
		//----------------------maptoLong---------------------------
		//List<Long> longs = … 
				//Stream cuyos elementos son la versión primitiva de  la lista definida arriba   LongStream 
				//stream = longs.stream().mapToLong(Long::longValue);
		
		System.out.println("********************************");
		//----------------------flatMap---------------------------
		List<String> lista = Arrays.asList("Taller", "Taller Lambdas y API  Stream"); 
		
		
		
		Stream listStr = lista.stream()
				.map(s ->  s.split(" ")) // Stream<String[]>   ---> ayuda a ver los arrays y aplicarle los separadores pero en el segundo se guarda como otro array con sus separadores            
				.map(Arrays::stream) //  Stream<Stream<String>>  ---> mira los arrays y aplica el mapeo
				.flatMap(Function.identity())// Stream<String>   ---> 
				.distinct(); //  Stream<String> de 5 elementos
		listStr.forEach(System.out::println);
		System.out.println("********************************");
		lista.stream().map(s -> s.split(" ")).forEach(System.out::println);
		
	}

}
